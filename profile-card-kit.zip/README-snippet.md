<p align="center">
  <img src="./profile-card.svg" alt="GitHub profile card" width="100%" />
</p>
